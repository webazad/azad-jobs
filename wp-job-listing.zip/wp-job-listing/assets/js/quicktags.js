;(function($){
    $(document).ready(function(){
        quicktags({
            id : 'preferred-requirements',
            buttons : 'em,strong,link'
        });
    });
})(jQuery);