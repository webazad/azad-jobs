jQuery(document).ready(function($){
    var sortList = $('ul#custom-type-list');
    var animation = $('#loading-animation');
    var pageTitle = $('div h1');
    
    sortList.sortable({
        update: function(event,ui){
            animation.show();
            $.ajax({
                //url: ajaxurl,
                url: WP_JOB_LISTING.azad,
                type:'POST',
                dataType: 'json',
                data:{
                    action: 'save_sort',
                    order: sortList.sortable( 'toArray' ),
                    security: WP_JOB_LISTING.security
                },
                success: function( response ){
                    $('div#message').remove();
                    animation.hide();
                    console.log(sortList.sortable( 'toArray' ).toString());
                    console.log('Success');
                    if(true === response.success){
                        pageTitle.after('<div id="message" class="updated below"><p>' + WP_JOB_LISTING.success + '</p></div>');
                    }else{
                        //pageTitle.after('<div id="message" class="error below"><p>' + WP_JOB_LISTING.failure + '</p></div>');
                    }
                },
                error: function( error ){
                    $('div#message').remove();
                    animation.hide();
                    console.log('Error');
                    pageTitle.after('<div id="message" class="error below"><p>'+ WP_JOB_LISTING.failure +'</p></div>');
                }
            });
        }        
    });
});