;(function($){
    $('.datepicker').datepicker();
})(jQuery);